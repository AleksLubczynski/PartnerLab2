//
//  PartnerLab_2Tests.swift
//  PartnerLab#2Tests
//
//  Created by Alex T on 10/13/25.
//

import Testing
@testable import PartnerLab_2

struct PartnerLab_2Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
