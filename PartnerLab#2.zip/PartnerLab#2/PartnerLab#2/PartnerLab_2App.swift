//
//  PartnerLab_2App.swift
//  PartnerLab#2
//
//  Created by Alex T on 10/13/25.
//

import SwiftUI

@main
struct PartnerLab_2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
