//
//  ContentView.swift
//  PartnerLab#2
//
//  Created by Alex T on 10/13/25.
//

import SwiftUI

let cardAssets = ["car1", "car2", "car3", "car4", "car5", "car6"]

class EmojiMemoryGame: ObservableObject {
    @Published private var model: MemoryGame<String> = EmojiMemoryGame.createMemoryGame()
    
    static func createMemoryGame() -> MemoryGame<String> {
        return MemoryGame<String>(numberOfPairsOfCards: cardAssets.count) { pairIndex in
            return cardAssets[pairIndex]
        }
    }
    
    var cards: [MemoryGame<String>.Card] {
        model.cards
    }
    
    func choose(card: MemoryGame<String>.Card) {
        model.choose(card)
    }
}

struct ContentView: View {
    @ObservedObject var game: EmojiMemoryGame = EmojiMemoryGame()
    
    let columns: [GridItem] = Array(repeating: .init(.flexible()), count: 4)

    var body: some View {
        VStack {
            Text("Cool Car Memory Game")
                .font(.largeTitle)
                .padding(.bottom)
            
            LazyVGrid(columns: columns, spacing: 10) {
                ForEach(game.cards.filter { !$0.isMatched }) { card in
                    CardView(card: card)
                        .onTapGesture {
                            game.choose(card: card)
                        }
                        .aspectRatio(2/3, contentMode: .fit)
                }
            }
            .padding()
            Spacer()
        }
    }
}

struct CardView: View {
    let card: MemoryGame<String>.Card
    
    var body: some View {
        ZStack {
            let shape = RoundedRectangle(cornerRadius: 15)
            
            if card.isFaceUp {
                shape.fill(.white)
                shape.strokeBorder(.blue, lineWidth: 3)
                
                Image(card.content)
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .padding(5)
            } else {
                shape.fill(.blue)
            }
        }
        .opacity(card.isMatched ? 0.0 : 1.0)
    }
}
